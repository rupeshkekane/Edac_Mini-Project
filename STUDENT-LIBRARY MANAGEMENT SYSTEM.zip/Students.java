package library;
import java.util.Scanner;

import java.text.SimpleDateFormat;  
import java.util.Date;
import java.time.temporal.ChronoUnit;
import java.time.*;

public class Students 
{
Scanner input = new Scanner(System.in);
Student theStudents[] = new Student[100];
public static int count = 0;

Date date = new Date();
LocalDate dateBefore,dateAfter;


public void addStudent(Student s)
{
    for (int i=0; i<count; i++)
    {
        if(s.regNum.equalsIgnoreCase(theStudents[i].regNum))
        {
            System.out.println("Student of Reg Num " + s.regNum + " is Already Registered.");
            return;
        }
    }
    if (count<=100)
    {
        theStudents[count] = s;
        count++;
    }
}


public void showAllStudents()
{
    System.out.println("Student Name\t\tRegister Number");
    for (int i=0; i<count; i++)
    {
        System.out.println(theStudents[i].studentName + "\t\t\t" + theStudents[i].regNum);
    }
}


public int isStudent()
{
    System.out.println("Enter Student Register Number:");
    String regNum = input.nextLine();
    for (int i=0; i<count; i++)
    {
        if (theStudents[i].regNum.equalsIgnoreCase(regNum))
        {
            return i;
        }
    }
    System.out.println("Student is not Registered.");
    System.out.println("Get Registered First.");
    return -1;
}


public void checkOutBook(Books book)
{
    int studentIndex =this.isStudent();
    if (studentIndex!=-1)
    {
        System.out.println("checking out");
        book.showAllBooks();
        Book b = book.checkOutBook();
        System.out.println("checking out");
        if (b!= null)
        {
            if (theStudents[studentIndex].booksCount<1)
            {
                System.out.println("adding book");
                theStudents[studentIndex].borrowedBooks[theStudents[studentIndex].booksCount] = b;
                theStudents[studentIndex].booksCount++;
                
                SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy hh.mm aa");  
                String strDate1= formatter.format(date);
                System.out.println("Checked Out Date Is "+strDate1); 
                try
                {
                	dateBefore = LocalDate.parse(strDate1);
                }
                catch(Exception e)
                {
                	System.out.println("Student Have To Renew Book In 15 Days Otherwise Student Have To Pay Penalty"); 
                }

                return;
            }
            else
            {
                System.out.println("Student Can not Borrow more than 1 Books.");
                System.out.println("Student have to return first book and borrow another book.");
                return;
            }
        }
        System.out.println("Book is not Available.");
    }
}


public void checkInBook(Books book)
{
    int studentIndex = this.isStudent();
    if (studentIndex != -1)
    {
        System.out.println("S.No\t\t\tBook Name\t\t\tAuthor Name");
        Student s = theStudents[studentIndex];
        for (int i=0; i<s.booksCount; i++)
        {
            System.out.println(s.borrowedBooks[i].sNo+ "\t\t\t" + s.borrowedBooks[i].bookName + "\t\t\t\t"+
                    s.borrowedBooks[i].authorName);
        }
        System.out.println("Enter Serial Number of Book to be Checked In:");
        int sNo = input.nextInt();
        for (int i=0; i<s.booksCount; i++)
        {
            if (sNo == s.borrowedBooks[i].sNo)
            {
                book.checkInBook(s.borrowedBooks[i]);
                s.borrowedBooks[i]=null;
               
                SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy hh.mm aa");  
                String strDate2= formatter.format(date); 
                System.out.println("Checked In Date  Is "+strDate2); 
                try {
                dateAfter = LocalDate.parse(strDate2);
            	long noOfDaysBetween = ChronoUnit.DAYS.between(dateBefore, dateAfter);
            	if(noOfDaysBetween>=15)
            	{
            		System.out.println("Student Have To Pay Rs.10 Penalty For Exceed Time Duration");
            	}
            	}
                catch(Exception e) 
                {
                System.out.println("No Penalty.Book Return In Time. ");
                }
                
     
                return;
            }
        }
        System.out.println("Book of Serial No "+sNo+"not Found");
    }
}
}
